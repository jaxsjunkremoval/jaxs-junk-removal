JAXS JUNK REMOVAL — FREE WEBSITE

Files:
- index.html — complete mobile-friendly website.

To publish for free:
1. Create a free account with a static website host such as GitHub Pages, Netlify, or Cloudflare Pages.
2. Upload index.html.
3. Set the site to deploy/publish.
4. You will receive a public website address.

Notes:
- The quote form opens the visitor's email app using the JAXS JUNK REMOVAL email address.
- Replace the email/phone details in index.html if your contact information changes.
- No paid hosting is required for the static site itself.
